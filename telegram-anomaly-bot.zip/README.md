# Telegram Anomaly Bot

Bot ini mengirim notifikasi anomaly crypto dan pelajaran via Telegram.

## Setup

1. Tambahkan environment variables:
   - TELEGRAM_TOKEN
   - TELEGRAM_CHAT_ID

2. Jalankan dengan `python main.py` atau deploy ke Railway.
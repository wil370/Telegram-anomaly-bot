import os
import time
import requests
from telegram import Bot

TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

bot = Bot(token=TOKEN)

def send_message(message):
    bot.send_message(chat_id=CHAT_ID, text=message)

if __name__ == "__main__":
    send_message("✅ Bot aktif! Siap kirim sinyal anomaly dan pelajaran crypto.")
    while True:
        time.sleep(3600)  # Simulasi bot aktif